Image Editor with the help of Gemini 
