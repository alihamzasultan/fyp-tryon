import React, { useState, useCallback, useEffect } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View, RefreshControl } from 'react-native';
import Button from '@/components/Button';
import Typo from '@/components/Typo';
import { colors, spacingX, spacingY } from '@/constants/theme';
import { useAuth } from '@/contexts/authContext';
import ScreenWrapper from '@/components/ScreenWrapper';
import { verticalScale } from '@/utils/styling';
import { Ionicons } from '@expo/vector-icons';
import HomeCard from '@/components/HomeCard';
import TransactionList from '@/components/TransactionList';
import { useRouter } from 'expo-router';
import { limit, orderBy, where } from 'firebase/firestore';
import useFetchData from '@/hooks/useFetchData';
import { TransactionType } from '@/types';
import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage

const Home = () => {
  const [showTransactions, setShowTransactions] = useState(false);

  const { user } = useAuth();
  const router = useRouter();

  const [refreshing, setRefreshing] = useState(false);
  const [currencySign, setCurrencySign] = useState<string>(''); // State for currency sign

  const constraints = [
    where("uid", "==", user?.uid),
    orderBy("date", "desc"),
    limit(30)
  ];
  const { 
    data: recentTransactions,
    error,
    loading: transactionsLoading
  } = useFetchData<TransactionType>("transactions", constraints);

  // Fetch currency sign from AsyncStorage when the component mounts
  const fetchCurrencySign = async () => {
    try {
      const storedCurrencySign = await AsyncStorage.getItem('currencySign');
      if (storedCurrencySign) {
        setCurrencySign(storedCurrencySign);
      }
    } catch (error) {
      console.error('Error fetching currency sign:', error);
    }
  };

  useEffect(() => {
    fetchCurrencySign(); // Fetch the currency sign when the component mounts
  }, []);

  // Handle refresh (pull-to-refresh)
  const onRefresh = useCallback(async () => {
    setRefreshing(true);

    try {
      // Fetch the updated currency sign from AsyncStorage
      const storedCurrencySign = await AsyncStorage.getItem('currencySign');
      if (storedCurrencySign) {
        setCurrencySign(storedCurrencySign); // Update state with the currency sign
      }
      
      // You can add any additional logic to refresh data here, e.g., fetching fresh transactions.
      setTimeout(() => {
        setRefreshing(false); // Stop refreshing after a delay
      }, 2000);
    } catch (error) {
      console.error('Error refreshing AsyncStorage:', error);
      setRefreshing(false);
    }
  }, []);

  return (
    <ScreenWrapper>
      <View style={styles.container}>
        {/* header */}
        <View style={styles.header}>
          <View style={{ gap: 4 }}>
            <Typo size={16} color={colors.neutral400}>
              Hello,
            </Typo>
            <Typo size={20} fontWeight={"500"}>
              {user?.name}
            </Typo>
          </View>
          <TouchableOpacity onPress={() => router.push('/(modals)/searchModal')} style={styles.searchIcon}>
            <Ionicons name="search" size={verticalScale(22)} color={colors.neutral200} />
          </TouchableOpacity>
        </View>

        <ScrollView
          contentContainerStyle={styles.scrollViewStyle}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        >
          <View>
            <HomeCard />
          </View>

          <View style={styles.transactionsHeader}>
  <Typo size={18} fontWeight="600">Recent Transactions</Typo>
  <TouchableOpacity onPress={() => setShowTransactions(prev => !prev)}>
    <Ionicons
      name={showTransactions ? "chevron-up-outline" : "chevron-down-outline"}
      size={20}
      color={colors.neutral400}
    />
  </TouchableOpacity>
</View>

{showTransactions && (
  <TransactionList
    data={recentTransactions}
    loading={transactionsLoading}
    emptyListMessage="No Transactions added yet!"
    title=""
  />
)}


          {/* Displaying Currency Sign */}

        </ScrollView>

        <Button style={styles.floatingButton} onPress={() => router.push('/(modals)/transactionModal')}>
          <Ionicons name="add" color={colors.black} size={verticalScale(24)} />
        </Button>
      </View>
    </ScreenWrapper>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: spacingX._20,
    marginTop: verticalScale(8),
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: spacingY._10,
  },
  searchIcon: {
    backgroundColor: colors.neutral700,
    padding: spacingX._10,
    borderRadius: 50,
  },
  transactionsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacingY._10,
  },
  
  floatingButton: {
    height: verticalScale(50),
    width: verticalScale(50),
    borderRadius: 100,
    position: "absolute",
    bottom: verticalScale(30),
    right: verticalScale(30),
  },
  scrollViewStyle: {
    marginTop: spacingY._10,
    paddingBottom: verticalScale(100),
    gap: spacingY._25,
  },
  currencySignContainer: {
    marginTop: verticalScale(20),
    padding: spacingX._10,
    backgroundColor: colors.neutral200,
    borderRadius: 8,
  },
});
