import React, { useState, useEffect } from 'react';
import {
  Modal,
  View,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  Image,
  Text
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacingX, spacingY, radius } from '@/constants/theme';
import Typo from '@/components/Typo';
import { useAuth } from '@/contexts/authContext';
import { firestore } from '@/config/firebase';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { ChatRoom } from '@/types';

const ShowAllChatsModal: React.FC<{ visible: boolean; onClose: () => void }> = ({ visible, onClose }) => {
  const { user } = useAuth();
  const router = useRouter();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!visible || !user?.uid) {
      setLoading(false);
      setChatRooms([]);
      return;
    }
  
    setLoading(true);
  
    const q = query(
      collection(firestore, 'chatRooms'),
      where('participantIds', 'array-contains', user.uid),
      orderBy('lastMessageTime', 'desc')   // 🔥 use correct field
    );
  
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const rooms = snapshot.docs.map((doc) => {
          const data = doc.data();
  
          return {
            id: doc.id,
            participants: data.participants,
            participantIds: data.participantIds,
            adInfo: data.adInfo || {},
  
            // map Firestore fields into our expected format
            lastMessage: data.lastMessage
              ? {
                  text: data.lastMessage,
                  senderId: data.lastMessageSenderId || '', // add this field in Firestore if needed
                  createdAt: data.lastMessageTime,
                }
              : undefined,
  
            updatedAt: data.lastMessageTime,
          } as ChatRoom;
        });
  
        console.log("🔥 ChatRooms fetched:", rooms);
        setChatRooms(rooms);
        setLoading(false);
      },
      (error) => {
        console.error("❌ Error loading chats:", error);
        setLoading(false);
      }
    );
  
    return () => unsubscribe();
  }, [visible, user?.uid]);
  
  const getOtherParticipant = (room: ChatRoom) => {
    if (!user?.uid) return null;
    const otherUserId = room.participantIds.find(id => id !== user.uid);
    return otherUserId ? room.participants[otherUserId] : null;
  };

  const renderChatItem = ({ item }: { item: ChatRoom }) => {
    const otherUser = getOtherParticipant(item);
    const lastMessage = item.lastMessage;
    const isCurrentUserSender = lastMessage?.senderId === user?.uid;

    return (
      <TouchableOpacity
      
        style={styles.chatItem}
        onPress={() => {
          console.log("➡️ Opening chat:", item.id);
          onClose();
          router.push(`/chat?roomId=${item.id}&adId=${item.adInfo?.title ?? "No title"}
`);
        }}
      >
        {otherUser?.image ? (
          <Image source={{ uri: otherUser.image }} style={styles.userImage} />
        ) : (
          <View style={[styles.userImage, styles.emptyUserImage]}>
            <Ionicons name="person" size={24} color={colors.neutral500} />
          </View>
        )}

        <View style={styles.chatContent}>
          <Text style={{ color: colors.white, fontWeight: 'bold' }}>
            {otherUser?.name || 'Unknown User'}
          </Text>
          <Text style={{ color: colors.neutral400 }}>
            {isCurrentUserSender ? 'You: ' : ''}{lastMessage?.text || 'No messages yet'}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={false}
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.header}>
        <TouchableOpacity onPress={onClose} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color={colors.white} />
            </TouchableOpacity>

          <Text style={styles.headerTitle}>Chats</Text>
        </View>
  
        <View style={styles.container}>
          {loading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={colors.primary} />
            </View>
          ) : chatRooms.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="chatbubble-outline" size={48} color={colors.neutral500} />
              <Text style={styles.noChatsText}>No chats found</Text>
            </View>
          ) : (
            <FlatList
              data={chatRooms}
              renderItem={renderChatItem}
              keyExtractor={(item) => item.id}
              contentContainerStyle={styles.listContent}
            />
          )}
        </View>
      </SafeAreaView>
    </Modal>
  );
  
};

const styles = StyleSheet.create({
    safeArea: { flex: 1, backgroundColor: colors.neutral900 },
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: spacingY._12,
      paddingHorizontal: spacingX._15,
      borderBottomWidth: 1,
      borderBottomColor: colors.neutral800,
    },
    backButton: {
      marginRight: spacingX._10,
      padding: 4,
    },
    headerTitle: {
      color: colors.white,
      fontSize: 18,
      fontWeight: 'bold',
    },
    container: { flex: 1, paddingHorizontal: spacingX._15 },
    loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
    noChatsText: { marginTop: 16, color: colors.white, fontSize: 16 },
    listContent: { paddingBottom: spacingY._20 },
    chatItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: spacingY._12,
      paddingHorizontal: spacingX._10,
      backgroundColor: colors.neutral800,
      borderRadius: radius._10,
      marginBottom: spacingY._10,
    },
    userImage: { width: 50, height: 50, borderRadius: 25, marginRight: spacingX._10 },
    emptyUserImage: { backgroundColor: colors.neutral700, justifyContent: 'center', alignItems: 'center' },
    chatContent: { flex: 1 },
  });
  
export default ShowAllChatsModal;
