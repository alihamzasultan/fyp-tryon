export const CLOUDINARY_CLOUD_NAME = "dg7joeqah";
export const CLOUDINARY_UPLOAD_PRESET = "images";
